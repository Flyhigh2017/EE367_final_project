import numpy as np
import cv2
from os import listdir
def contrast(img):
    clahe = cv2.createCLAHE(clipLimit=3., tileGridSize=(4,4))

    lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)  # convert from BGR to LAB color space
    l, a, b = cv2.split(lab)  # split on 3 different channels

    l2 = clahe.apply(l)  # apply CLAHE to the L-channel

    lab = cv2.merge((l2,a,b))  # merge channels
    img2 = cv2.cvtColor(lab, cv2.COLOR_LAB2BGR)  # convert from LAB to BGR
    return img2
def cont2(img):
    img_yuv = cv2.cvtColor(img, cv2.COLOR_BGR2YUV)

    # equalize the histogram of the Y channel
    img_yuv[:,:,0] = cv2.equalizeHist(img_yuv[:,:,0])

    # convert the YUV image back to RGB format
    img_output = cv2.cvtColor(img_yuv, cv2.COLOR_YUV2BGR)
    return img_output
'''
img = cv2.imread("/Users/anekisei/Documents/UAV_dataset/1108304611.jpg")
res = cont2(img)
cv2.imshow('image',res)
cv2.waitKey(0)
'''
