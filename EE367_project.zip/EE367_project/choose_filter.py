#/usr/bin/env python
# -*- coding: UTF-8 -*-
import numpy as np
import cv2
import os
from os import listdir
from os.path import isfile, join
import matplotlib.pyplot as plt
from numpy.fft import fft2, ifft2
import skimage
import matplotlib.pyplot as plt
import random
def gauss2D(shape=(3,3),sigma=0.5):
    """
        2D gaussian mask - should give the same result as MATLAB's
        fspecial('gaussian',[shape],[sigma])
        """
    m,n = [(ss-1.)/2. for ss in shape]
    y,x = np.ogrid[-m:m+1,-n:n+1]
    h = np.exp( -(x*x + y*y) / (2.*sigma*sigma) )
    h[ h < np.finfo(h.dtype).eps*h.max() ] = 0
    sumh = h.sum()
    if sumh != 0:
        h /= sumh
    return h

def psnr(target, ref):
    target_data = np.array(target, dtype=np.float64)
    ref_data = np.array(ref,dtype=np.float64)
    
    diff = ref_data - target_data
    diff = diff.flatten('C')
    
    rmse = np.sqrt(np.mean(diff ** 2.))
    
    return 20 * np.log10(255 / rmse)

def wiener_filter(img, kernel, K = 0.5):
    dummy = np.copy(img)
    kernel = np.pad(kernel, [(0, dummy.shape[0] - kernel.shape[0]), (0, dummy.shape[1] - kernel.shape[1])], 'constant')
    # Fourier Transform
    dummy = fft2(dummy)
    kernel = fft2(kernel)
    kernel = np.conj(kernel) / (np.abs(kernel) ** 2 + K)
    dummy = dummy * kernel
    dummy = np.abs(ifft2(dummy))
    return np.uint8(dummy)
def gaussian_filter(img):
    return cv2.GaussianBlur(img,(5,5),0)
def average_filter(img):
    return cv2.blur(img,(5,5))
def bilateral_filter(img):
    return cv2.bilateralFilter(img,10,30,30)
def combination_filter(img,K):
    gray = wiener_filter(img, kernel = kernel, K = K/0.5)
    gray = cv2.bilateralFilter(gray,10,30,30)
    res = cv2.medianBlur(gray, 3)
    return res

def sp_noise(image,prob):
    '''
    Add salt and pepper noise to image
    prob: Probability of the noise
    '''
    output = np.zeros(image.shape,np.uint8)
    thres = 1 - prob
    for i in range(image.shape[0]):
        for j in range(image.shape[1]):
            rdn = random.random()
            if rdn < prob:
                output[i][j] = 0
            elif rdn > thres:
                output[i][j] = 255
            else:
                output[i][j] = image[i][j]
    return output

kernel = gauss2D()
data_path1 = "/Users/anekisei/Documents/367/crop"
num_image = len(listdir(data_path1)) + 0.0
def find_best_K():
    for im_name in listdir(data_path1):
        K_ = [0, 0.001, 0.01, 0.1, 1, 2]
        orig = cv2.imread(data_path1 + "/" + im_name,0)
        img = sp_noise(orig,0.05)
        print "start"
        y_axis = []
        x_axis = []
        for K in K_:
            res = combination_filter(img,K)
            print "K = ",K / 0.5, "PSNR = ", psnr(res,orig)
            x_axis.append(K / 0.5)
            y_axis.append(psnr(res,orig))
        print "finish"
        plt.plot([np.log10(x) for x in x_axis], y_axis, 'ro')
        plt.xlabel('K in log10 scale')
        plt.ylabel('PSNR')
        plt.show()

def find_avg_psnr():
    ratio = 0.0
    for im_name in listdir(data_path1):
        orig = cv2.imread(data_path1 + "/" + im_name,0)
        img = sp_noise(orig,0.05)
        print "start"
        res = combination_filter(img, 0.1)
        print "finish"
        ratio += psnr(res,orig)
        cv2.imwrite("/Users/anekisei/Documents/367/crop_result/"+im_name, res)
    return ratio / num_image

print find_avg_psnr()
#find_best_K()
#gaussian 23.31 average 24.10 bilateral 14.18 combine 24.36




